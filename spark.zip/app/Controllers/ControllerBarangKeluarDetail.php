<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class ControllerBarangKeluarDetail extends BaseController
{
    public function index()
    {
        //
    }
}
